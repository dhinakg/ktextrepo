BootInstall
===========

This tool installs legacy DuetPkg environment on GPT-formatted disk
to enable UEFI environment on BIOS-based systems.

Source code: https://sourceforge.net/p/cloverefiboot
